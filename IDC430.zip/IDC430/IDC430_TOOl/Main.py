#!usr/bin/env python
# -*- coding: UTF-8 -*-
import sys
import socket
import binascii
import struct
import os
ip_port = None
fn_code_str = {0x4104 : '请求时钟', 0x4106 : '查询版本号', 0x4108: '获取RAM数据'}
u16_lit = struct.Struct('<H')
s16_lit = struct.Struct('<h')
u32_lit = struct.Struct('<I')
s32_lit = struct.Struct('<i')

u16_big = struct.Struct('>H')
s16_big = struct.Struct('>h')
u32_big = struct.Struct('>I')
s32_big = struct.Struct('>i')

def get_CRC_16(data):
    Rc = 0xffff

    for i in range(0, len(data)):
        Rc ^= data[i]
        # print(data[i])
        for j in range(0, 8):
            if Rc & 1:
                Rc >>= 1
                Rc ^= 0xa001
            else:
                Rc >>= 1
    return Rc

def get_frame (fn_cde, data):
    msg = bytearray()
    frame_size = len(data) + 9
    msg.append(0x01)
    msg.append(frame_size >> 8 & 0xff)
    msg.append(frame_size & 0xff)
    msg.append(fn_cde >> 8 & 0xff)
    msg.append(fn_cde & 0xff)
    msg.append(0)# obj type
    msg.append(0)# obj id hi
    msg.append(0)#obj id lo
    msg.append(0) # version
    msg.append(0)# sub cat
    msg.extend(data)
    crc = get_CRC_16(msg[1:])
    msg.append(crc & 0xff)
    msg.append(crc >> 8 & 0xff)

    return msg

def find_fram():
    msg = bytearray()
    msg.append(0x55)
    msg.append(0xaa)
    msg.append(0x1c)
    msg.extend('WHO IS IDC400V2 DEVICE?'.encode())
    msg.append(0xeb)
    msg.append(0x90)
    return msg

def decode_fn(data):
    if len(data) < 12:
        print('frame err.')
        return {}
    msg = {}
    msg['start_code'] = data[0]
    msg['len'] = u16_big.unpack_from(data, 1)[0]
    msg['fn_code'] = u16_big.unpack_from(data, 3)[0]
    msg['obj_type'] = data[5]
    msg['objID']  = u16_big.unpack_from(data, 6)[0]
    msg['version'] = data[7]
    msg['obj_subid']  = data[8]

    if len(data) > 12:
        msg['data'] = data[10: -2]

    crc = u16_lit.unpack_from(data, len(data) -2)[0]
    temp = get_CRC_16(data[1: -2])
    msg['crc'] = temp
    if crc != temp:
        print(binascii.hexlify(data))
        print(msg)
        print('crc:%x %x' % (crc, temp))
        return None


    if msg:
        if msg['fn_code'] in fn_code_str.keys():
            print(fn_code_str[msg['fn_code']])
            if '请求时钟' == fn_code_str[msg['fn_code']]:
                if 'data' in msg.keys():
                    temp_data = msg['data']
                    if len(temp_data) != 7:
                        print('clk format err.')
                    else:
                        out = '时钟:%04d%02d%02d%02d%02d%02d'% (\
                            u16_big.unpack_from(temp_data,0)[0], temp_data[2],\
                           temp_data[3],temp_data[4],temp_data[5],temp_data[6])
                        return out
            elif '查询版本号' == fn_code_str[msg['fn_code']]:
                pass
            elif '获取RAM数据' == fn_code_str[msg['fn_code']]:
                if 'data' in msg.keys():
                    print(binascii.hexlify(msg['data']) )
                else:
                    print('输入错误')
            else:
                pass
        else:
            print('不支持:%d' %(msg['fn_code']))
            return None
    return msg

def get_sys_time():
    try:
        send_msg = get_frame(0x4104, '')
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(1)
        client.sendto(send_msg, ip_port)
        data, server_addr = client.recvfrom(1024)
        msg = decode_fn(data)
        client.close()
        return msg
    except Exception as e:
        print(e)

def get_ram_data():
    addr_str = input('请输入地址:')
    try:
        addr = int(addr_str, 16)
        msg = bytearray()
        msg.append(addr & 0xff)
        msg.append(addr >> 8 & 0xff)
        msg.append(addr >> 16 & 0xff)
        msg.append(addr >> 24 & 0xff)
        print('addr:0x%x' % (addr))
        try:
            send_msg = get_frame(0x4108, msg)
            client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            client.settimeout(1)
            client.sendto(send_msg, ip_port)
            data, server_addr = client.recvfrom(1024)
            msg = decode_fn(data)
            client.close()
            return msg
        except Exception as e:
            print(e)
    except Exception as e:
        print(e)

def out_emnu():
    print('#####################')
    print('版本号:V0.0.1')
    print('AHTH: WZD')
    print('发布时间:20200706')
    print('#####################')
    print('菜单:')
    print('SN    note')
    print('1    获取时间')
    print('2    获取内存')
    print('0    退出')
    print('---------------------------')

if __name__ == "__main__":

    cnt = len(sys.argv)
    if cnt == 2:
        ip_port = (sys.argv[1], 4350)
    else:
        ip_port = ("172.20.46.178", 4350)

    try:
        while True:
            out_emnu()
            msg = input('请输入指令:')
            if msg == '1':
                run_time = get_sys_time()
                print(run_time)
            elif msg == '2':
                get_ram_data()
            elif msg == '0':
                sys.exit()
    except KeyboardInterrupt:
        print('退出')
        sys.exit()
    except Exception as e:
        print(e)
       # import time
       #      os.system('cls')